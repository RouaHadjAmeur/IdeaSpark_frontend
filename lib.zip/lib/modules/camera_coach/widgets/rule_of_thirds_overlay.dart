// Rule of Thirds Overlay Widget
import 'package:flutter/material.dart';

class RuleOfThirdsOverlay extends StatelessWidget {
  const RuleOfThirdsOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
