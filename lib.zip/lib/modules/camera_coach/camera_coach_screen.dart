// Camera Coach Screen
import 'package:flutter/material.dart';

class CameraCoachScreen extends StatelessWidget {
  const CameraCoachScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Center(
        child: Text('Camera Coach Screen'),
      ),
    );
  }
}
